import os
os.rename('career.guru99.txt','guru99.txt')