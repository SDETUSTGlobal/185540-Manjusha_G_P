# Read a File line by line
f=open("guru99.txt", "r")
f1=f.readline()
for x in f1:
     print(x)